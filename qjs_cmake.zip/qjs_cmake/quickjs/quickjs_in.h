//
//  quickjs_in.h
//  quickjs_osx
//
//  Created by gen on 12/9/20.
//  Copyright © 2020 nioqio. All rights reserved.
//

#ifndef quickjs_in_h
#define quickjs_in_h

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* quickjs_in_h */
